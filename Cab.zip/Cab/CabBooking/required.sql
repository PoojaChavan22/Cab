CREATE TABLE cab (carid NUMBER PRIMARY KEY, name VARCHAR2 (20), pincode VARCHAR2(6));

INSERT INTO cab VALUES(1001,'Tata Indica','600157');
INSERT INTO cab VALUES(1002,'Mahindra','688157');
INSERT INTO cab VALUES(1003,'Hyundai','612157');

CREATE TABLE cabcustomer(purchaseid NUMBER, cname vARCHAR2(20), 
address VARCHAR2(30),phoneno VARCHAR2(12), regdate DATE, 
pin VARCHAR2(6));


CREATE SEQUENCE customer_sequence
START WITH 1;