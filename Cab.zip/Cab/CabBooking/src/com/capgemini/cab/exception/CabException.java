package com.capgemini.cab.exception;

public class CabException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6234391941897466540L;

	public CabException(){
		super();
	}

	public CabException(String message) {
		super(message);
	}
	
	
	
}
