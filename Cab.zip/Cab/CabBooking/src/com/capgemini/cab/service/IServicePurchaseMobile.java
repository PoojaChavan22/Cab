package com.capgemini.cab.service;

import java.util.List;

import com.capgemini.cab.bean.MobileBean;
import com.capgemini.cab.bean.PurchaseDetailsBean;
import com.capgemini.cab.exception.MobilePurchaseException;

public interface IServicePurchaseMobile {
      
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean) throws MobilePurchaseException;
	

	
	
}
